import {
  AppSettings,
  BillingCycle,
  FoodPreset,
  MealTransaction,
} from '../types/mess';
import {
  calculateCycleEndDate,
  toLocalDateString,
} from '../utils/calculations';

const DB_NAME = 'vit_messmate_db';
const DB_VERSION = 1;

const STORE_CYCLES = 'cycles';
const STORE_TRANSACTIONS = 'transactions';
const STORE_PRESETS = 'presets';
const STORE_SETTINGS = 'settings';

export const DEFAULT_PRESETS: FoodPreset[] = [
  { id: 'preset-bf-standard', foodName: 'Masala Dosa & Coffee', category: 'Breakfast', credits: 75, tags: ['South Indian', 'Morning'] },
  { id: 'preset-lunch-thali', foodName: 'Special Executive Lunch', category: 'Lunch', credits: 110, tags: ['Thali', 'Full Meal'] },
  { id: 'preset-snacks-samosa', foodName: 'Samosa & Ginger Chai', category: 'Snacks', credits: 40, tags: ['Evening', 'Hot'] },
  { id: 'preset-dinner-combo', foodName: 'Paneer Butter Masala & Rotis', category: 'Dinner', credits: 120, tags: ['North Indian', 'Dinner'] },
  { id: 'preset-bf-idli', foodName: 'Idli Vada Sambar', category: 'Breakfast', credits: 60, tags: ['Light', 'South Indian'] },
  { id: 'preset-lunch-mini', foodName: 'Mini Meals & Buttermilk', category: 'Lunch', credits: 85, tags: ['Quick Lunch'] },
  { id: 'preset-dinner-biryani', foodName: 'Special Veg / Chicken Biryani', category: 'Dinner', credits: 135, tags: ['Special'] },
  { id: 'preset-bev-juice', foodName: 'Fresh Watermelon Juice', category: 'Beverages', credits: 35, tags: ['Refreshment'] },
];

export function createDefaultCycleAndSeedData(todayStr: string = toLocalDateString()): {
  cycles: BillingCycle[];
  transactions: MealTransaction[];
  settings: AppSettings;
  presets: FoodPreset[];
} {
  // Start with a clean 30-day cycle. Never insert fictional meal transactions.
  const startDate = todayStr;
  const endDate = calculateCycleEndDate(startDate, 30);
  const activeCycleId = `cycle-${startDate}`;

  const activeCycle: BillingCycle = {
    id: activeCycleId,
    name: `Current Cycle (${startDate} to ${endDate})`,
    dailyReference: 288,
    cycleDuration: 30,
    monthlyBudget: 8640,
    startDate,
    endDate,
    isArchived: false,
    createdAt: Date.now(),
  };

  const settings: AppSettings = {
    theme: 'dark',
    creditDisplayFormat: 'integer-preferred',
    creditSymbol: 'cr',
    dailyReminderEnabled: true,
    dailyReminderTime: '21:00',
    overspendingAlertEnabled: true,
    lowBalanceAlertThreshold: 1200,
    activeCycleId,
  };

  return {
    cycles: [activeCycle],
    transactions: [],
    settings,
    presets: [],
  };
}

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB is not supported in this environment'));
      return;
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_CYCLES)) {
        db.createObjectStore(STORE_CYCLES, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORE_TRANSACTIONS)) {
        const txStore = db.createObjectStore(STORE_TRANSACTIONS, { keyPath: 'id' });
        txStore.createIndex('cycleId', 'cycleId', { unique: false });
        txStore.createIndex('date', 'date', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORE_PRESETS)) {
        db.createObjectStore(STORE_PRESETS, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORE_SETTINGS)) {
        db.createObjectStore(STORE_SETTINGS, { keyPath: 'id' });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function getAllFromStore<T>(db: IDBDatabase, storeName: string): Promise<T[]> {
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    const req = store.getAll();
    req.onsuccess = () => resolve(req.result as T[]);
    req.onerror = () => reject(req.error);
  });
}

export async function loadInitialDataFromDB(): Promise<{
  cycles: BillingCycle[];
  transactions: MealTransaction[];
  settings: AppSettings;
  presets: FoodPreset[];
}> {
  try {
    const db = await openDatabase();
    const [cycles, transactions, presets, settingsRows] = await Promise.all([
      getAllFromStore<BillingCycle>(db, STORE_CYCLES),
      getAllFromStore<MealTransaction>(db, STORE_TRANSACTIONS),
      getAllFromStore<FoodPreset>(db, STORE_PRESETS),
      getAllFromStore<{ id: string; value: AppSettings }>(db, STORE_SETTINGS),
    ]);

    if (cycles.length === 0) {
      const seed = createDefaultCycleAndSeedData();
      await saveAllDataToDB(seed.cycles, seed.transactions, seed.settings, seed.presets);
      db.close();
      return seed;
    }

    const storedSettings = settingsRows.find((r) => r.id === 'app_settings')?.value;
    const fallbackSeed = createDefaultCycleAndSeedData();
    const activeCycleExists =
      storedSettings && cycles.some((c) => c.id === storedSettings.activeCycleId);

    const finalSettings: AppSettings = storedSettings
      ? {
          ...fallbackSeed.settings,
          ...storedSettings,
          activeCycleId: activeCycleExists
            ? storedSettings.activeCycleId
            : cycles.find((c) => !c.isArchived)?.id || cycles[0].id,
        }
      : {
          ...fallbackSeed.settings,
          activeCycleId: cycles.find((c) => !c.isArchived)?.id || cycles[0].id,
        };

    db.close();
    return {
      cycles: cycles.sort((a, b) => b.createdAt - a.createdAt),
      transactions,
      settings: finalSettings,
      presets: presets.length > 0 ? presets : DEFAULT_PRESETS,
    };
  } catch (err) {
    console.warn('IndexedDB fallback to localStorage:', err);
    const raw = localStorage.getItem('vit_messmate_fallback');
    if (raw) {
      return JSON.parse(raw);
    }
    const seed = createDefaultCycleAndSeedData();
    localStorage.setItem('vit_messmate_fallback', JSON.stringify(seed));
    return seed;
  }
}

export async function saveAllDataToDB(
  cycles: BillingCycle[],
  transactions: MealTransaction[],
  settings: AppSettings,
  presets: FoodPreset[]
): Promise<void> {
  try {
    const db = await openDatabase();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(
        [STORE_CYCLES, STORE_TRANSACTIONS, STORE_PRESETS, STORE_SETTINGS],
        'readwrite'
      );

      const cycleStore = tx.objectStore(STORE_CYCLES);
      cycleStore.clear();
      for (const c of cycles) cycleStore.put(c);

      const txStore = tx.objectStore(STORE_TRANSACTIONS);
      txStore.clear();
      for (const t of transactions) txStore.put(t);

      const presetStore = tx.objectStore(STORE_PRESETS);
      presetStore.clear();
      for (const p of presets) presetStore.put(p);

      const settingsStore = tx.objectStore(STORE_SETTINGS);
      settingsStore.put({ id: 'app_settings', value: settings });

      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
    db.close();
  } catch {
    localStorage.setItem(
      'vit_messmate_fallback',
      JSON.stringify({ cycles, transactions, settings, presets })
    );
  }
}
