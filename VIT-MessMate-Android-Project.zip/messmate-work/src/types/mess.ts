export type MealCategory =
  | 'Breakfast'
  | 'Lunch'
  | 'Snacks'
  | 'Dinner'
  | 'Beverages'
  | 'Other';

export const MEAL_CATEGORIES: MealCategory[] = [
  'Breakfast',
  'Lunch',
  'Snacks',
  'Dinner',
  'Beverages',
  'Other',
];

export interface MealTransaction {
  id: string;
  cycleId: string;
  category: MealCategory;
  foodName: string;
  /** Credit cost per unit or total credit cost (stored as total credits for the entry) */
  credits: number;
  /** Unit price when quantity > 1 */
  unitCredits?: number;
  quantity: number;
  /** YYYY-MM-DD in local time */
  date: string;
  /** HH:mm in 24h format */
  time: string;
  notes?: string;
  tags?: string[];
  createdAt: number;
  updatedAt: number;
}

export interface BillingCycle {
  id: string;
  name: string;
  dailyReference: number; // default 288
  cycleDuration: number; // default 30
  monthlyBudget: number; // default 8640 (288 * 30) or custom starting credits
  startDate: string; // YYYY-MM-DD
  endDate: string; // YYYY-MM-DD
  isArchived: boolean;
  createdAt: number;
}

export interface FoodPreset {
  id: string;
  foodName: string;
  category: MealCategory;
  credits: number;
  tags?: string[];
}

export interface AppSettings {
  theme: 'dark' | 'light';
  creditDisplayFormat: 'integer-preferred' | 'two-decimals';
  creditSymbol: string; // e.g., 'cr' or 'credits'
  dailyReminderEnabled: boolean;
  dailyReminderTime: string; // e.g., '21:00'
  overspendingAlertEnabled: boolean;
  lowBalanceAlertThreshold: number; // e.g., 1000 credits
  activeCycleId: string;
}

export interface CycleMetrics {
  monthlyBudget: number;
  dailyReference: number;
  cycleDuration: number;
  totalUsed: number;
  remainingCredits: number;
  percentageUsed: number;
  daysElapsed: number;
  daysRemaining: number;
  isCycleEnded: boolean;
  isCycleFuture: boolean;
  recommendedDailyAllowance: number;
  averageDailySpendSoFar: number;
  spendingPaceStatus: 'below-reference' | 'on-reference' | 'above-reference' | 'over-budget' | 'cycle-ended';
  projectedEndBalance: number;
  isSustainable: boolean;
}

export interface TodayBreakdown {
  date: string;
  totalSpent: number;
  mealCount: number;
  dailyReference: number;
  differenceFromReference: number;
  byCategory: Record<MealCategory, number>;
  transactions: MealTransaction[];
}

export interface ScenarioProjection {
  id: string;
  label: string;
  dailySpend: number;
  totalFutureSpend: number;
  projectedTotalUsed: number;
  projectedEndBalance: number;
  willExceedBudget: boolean;
  daysUntilDepleted: number | null;
}

export interface DaySummary {
  date: string; // YYYY-MM-DD
  totalCredits: number;
  mealCount: number;
  status: 'no-data' | 'below' | 'on-reference' | 'above';
  transactions: MealTransaction[];
}

export interface SmartInsight {
  id: string;
  type: 'positive' | 'warning' | 'neutral' | 'info';
  title: string;
  description: string;
  metric?: string;
}
