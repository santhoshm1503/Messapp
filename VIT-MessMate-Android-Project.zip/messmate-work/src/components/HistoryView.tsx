import React, { useMemo, useState } from 'react';
import {
  BillingCycle,
  MEAL_CATEGORIES,
  MealCategory,
  MealTransaction,
} from '../types/mess';
import { formatCredits, roundCredits } from '../utils/calculations';
import {
  Copy,
  Download,
  Edit3,
  Filter,
  RotateCcw,
  Search,
  Trash2,
  Utensils,
} from 'lucide-react';

interface HistoryViewProps {
  cycles: BillingCycle[];
  activeCycleId: string;
  transactions: MealTransaction[];
  creditFormat: 'integer-preferred' | 'two-decimals';
  recentlyDeleted: MealTransaction | null;
  onEditTransaction: (tx: MealTransaction) => void;
  onDeleteTransaction: (id: string) => void;
  onUndoDelete: () => void;
  onDuplicateTransaction: (tx: MealTransaction) => void;
  onExportCSV: () => void;
}

type SortOrder = 'newest' | 'oldest' | 'highest' | 'lowest';

export const HistoryView: React.FC<HistoryViewProps> = ({
  cycles,
  activeCycleId,
  transactions,
  creditFormat,
  recentlyDeleted,
  onEditTransaction,
  onDeleteTransaction,
  onUndoDelete,
  onDuplicateTransaction,
  onExportCSV,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<'All' | MealCategory>('All');
  const [selectedCycleFilter, setSelectedCycleFilter] = useState<string>(activeCycleId);
  const [dateFilter, setDateFilter] = useState<string>('');
  const [minCredits, setMinCredits] = useState<string>('');
  const [maxCredits, setMaxCredits] = useState<string>('');
  const [sortOrder, setSortOrder] = useState<SortOrder>('newest');

  const filteredTransactions = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const minVal = minCredits !== '' ? parseFloat(minCredits) : null;
    const maxVal = maxCredits !== '' ? parseFloat(maxCredits) : null;

    const list = transactions.filter((tx) => {
      if (selectedCycleFilter !== 'all' && tx.cycleId !== selectedCycleFilter) {
        return false;
      }
      if (selectedCategory !== 'All' && tx.category !== selectedCategory) {
        return false;
      }
      if (dateFilter && tx.date !== dateFilter) {
        return false;
      }
      if (minVal !== null && Number.isFinite(minVal) && tx.credits < minVal) {
        return false;
      }
      if (maxVal !== null && Number.isFinite(maxVal) && tx.credits > maxVal) {
        return false;
      }
      if (q) {
        const matchName = tx.foodName.toLowerCase().includes(q);
        const matchNotes = tx.notes ? tx.notes.toLowerCase().includes(q) : false;
        const matchTags = tx.tags ? tx.tags.some((t) => t.toLowerCase().includes(q)) : false;
        const matchCat = tx.category.toLowerCase().includes(q);
        if (!matchName && !matchNotes && !matchTags && !matchCat) {
          return false;
        }
      }
      return true;
    });

    return list.sort((a, b) => {
      if (sortOrder === 'newest') {
        return (
          b.date.localeCompare(a.date) ||
          b.time.localeCompare(a.time) ||
          b.createdAt - a.createdAt
        );
      }
      if (sortOrder === 'oldest') {
        return (
          a.date.localeCompare(b.date) ||
          a.time.localeCompare(b.time) ||
          a.createdAt - b.createdAt
        );
      }
      if (sortOrder === 'highest') {
        return b.credits - a.credits || b.date.localeCompare(a.date);
      }
      return a.credits - b.credits || b.date.localeCompare(a.date);
    });
  }, [
    transactions,
    selectedCycleFilter,
    selectedCategory,
    dateFilter,
    minCredits,
    maxCredits,
    searchQuery,
    sortOrder,
  ]);

  const filteredTotalCredits = useMemo(
    () => roundCredits(filteredTransactions.reduce((sum, t) => sum + t.credits, 0)),
    [filteredTransactions]
  );

  const clearFilters = () => {
    setSearchQuery('');
    setSelectedCategory('All');
    setDateFilter('');
    setMinCredits('');
    setMaxCredits('');
    setSortOrder('newest');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
            Food & Transaction History
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Search, filter, sort, edit, or delete meal records across current and past billing cycles.
          </p>
        </div>

        <button
          type="button"
          onClick={onExportCSV}
          className="inline-flex items-center gap-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#111C33] hover:bg-slate-50 dark:hover:bg-slate-800 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 transition-colors self-start sm:self-auto cursor-pointer"
        >
          <Download className="w-3.5 h-3.5 text-emerald-500" />
          <span>Export CSV</span>
        </button>
      </div>

      {/* Undo Recently Deleted Banner */}
      {recentlyDeleted && (
        <div
          role="status"
          className="rounded-xl border border-amber-500/40 bg-amber-500/10 px-4 py-3 flex items-center justify-between gap-4"
        >
          <div className="text-xs text-slate-800 dark:text-slate-200">
            Deleted <strong>{recentlyDeleted.foodName}</strong> ({formatCredits(recentlyDeleted.credits, creditFormat)} cr). Credits have been restored to your balance.
          </div>
          <button
            type="button"
            onClick={onUndoDelete}
            className="inline-flex items-center gap-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 px-3 py-1.5 text-xs font-semibold text-white whitespace-nowrap shrink-0 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Undo Delete</span>
          </button>
        </div>
      )}

      {/* Search, Filter & Sort Controls */}
      <section
        aria-label="Filter and Sort Transactions"
        className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111C33] p-5 space-y-4"
      >
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3.5">
          {/* Search by Food Name / Notes / Tags */}
          <div className="md:col-span-5 relative">
            <label htmlFor="history-search" className="sr-only">
              Search food name, notes, or tags
            </label>
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              id="history-search"
              type="text"
              placeholder="Search food name, notes, or tags..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 pl-9 pr-3.5 py-2 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          {/* Billing Cycle Selector */}
          <div className="md:col-span-4">
            <label htmlFor="history-cycle-select" className="sr-only">
              Filter by Billing Cycle
            </label>
            <select
              id="history-cycle-select"
              value={selectedCycleFilter}
              onChange={(e) => setSelectedCycleFilter(e.target.value)}
              className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 px-3 py-2 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              {cycles.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} {c.isArchived ? '(Archived)' : '(Current)'}
                </option>
              ))}
              <option value="all">All Billing Cycles ({transactions.length} total)</option>
            </select>
          </div>

          {/* Sort Order */}
          <div className="md:col-span-3">
            <label htmlFor="history-sort-select" className="sr-only">
              Sort transactions
            </label>
            <select
              id="history-sort-select"
              value={sortOrder}
              onChange={(e) => setSortOrder(e.target.value as SortOrder)}
              className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 px-3 py-2 text-xs font-semibold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
            >
              <option value="newest">Sort: Newest First</option>
              <option value="oldest">Sort: Oldest First</option>
              <option value="highest">Sort: Highest Credits</option>
              <option value="lowest">Sort: Lowest Credits</option>
            </select>
          </div>
        </div>

        {/* Second Filter Row: Meal Category Tabs + Date + Credit Range */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
          <div className="flex flex-wrap items-center gap-1.5">
            {(['All', ...MEAL_CATEGORIES] as const).map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-emerald-600 text-white'
                    : 'bg-slate-100 dark:bg-slate-800/80 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <input
              type="date"
              aria-label="Filter by date"
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              className="rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 px-2.5 py-1.5 text-xs font-mono text-slate-900 dark:text-white"
            />
            <input
              type="number"
              aria-label="Minimum credits"
              placeholder="Min cr"
              value={minCredits}
              onChange={(e) => setMinCredits(e.target.value)}
              className="w-20 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 px-2.5 py-1.5 text-xs font-mono text-slate-900 dark:text-white"
            />
            <input
              type="number"
              aria-label="Maximum credits"
              placeholder="Max cr"
              value={maxCredits}
              onChange={(e) => setMaxCredits(e.target.value)}
              className="w-20 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 px-2.5 py-1.5 text-xs font-mono text-slate-900 dark:text-white"
            />
            {(searchQuery ||
              selectedCategory !== 'All' ||
              dateFilter ||
              minCredits ||
              maxCredits) && (
              <button
                type="button"
                onClick={clearFilters}
                className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:underline px-2 py-1 cursor-pointer"
              >
                Reset Filters
              </button>
            )}
          </div>
        </div>
      </section>

      {/* Filtered Results Table / List */}
      <section
        aria-label="Transaction History Results"
        className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111C33] overflow-hidden"
      >
        <div className="px-5 py-3.5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
          <span className="text-slate-600 dark:text-slate-400 flex items-center gap-1.5">
            <Filter className="w-3.5 h-3.5 text-emerald-500" />
            <span>
              Showing <strong className="font-mono tabular-nums text-slate-900 dark:text-white">{filteredTransactions.length}</strong> meal record{filteredTransactions.length === 1 ? '' : 's'}
            </span>
          </span>
          <span className="font-mono tabular-nums text-slate-700 dark:text-slate-300">
            Filtered Total:{' '}
            <strong className="text-emerald-600 dark:text-emerald-400">
              {formatCredits(filteredTotalCredits, creditFormat)} cr
            </strong>
          </span>
        </div>

        {filteredTransactions.length === 0 ? (
          <div className="p-10 text-center">
            <Utensils className="w-7 h-7 text-slate-400 mx-auto mb-2" />
            <div className="text-sm font-semibold text-slate-800 dark:text-slate-200">
              No matching meal transactions found
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Try clearing your search query or adjusting the category and date filters.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800/80">
            {filteredTransactions.map((tx) => (
              <div
                key={tx.id}
                className="px-5 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/60 dark:hover:bg-slate-800/30 transition-colors"
              >
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-slate-900 dark:text-white">
                    {tx.foodName}
                  </div>
                  {/* Clean unboxed metadata per Zero-Pill Discipline */}
                  <div className="text-xs text-slate-500 dark:text-slate-400 mt-1 flex flex-wrap items-center gap-1.5">
                    <span className="font-medium text-slate-700 dark:text-slate-300">
                      {tx.category}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono tabular-nums">{tx.date}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono tabular-nums">{tx.time}</span>
                    {tx.quantity > 1 && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className="font-mono tabular-nums">
                          Qty {tx.quantity} ({formatCredits(tx.unitCredits || tx.credits / tx.quantity, creditFormat)} cr each)
                        </span>
                      </>
                    )}
                    {tx.tags && tx.tags.length > 0 && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span>{tx.tags.join(' / ')}</span>
                      </>
                    )}
                  </div>
                  {tx.notes && (
                    <p className="text-xs text-slate-500 dark:text-slate-400 italic mt-1">
                      {tx.notes}
                    </p>
                  )}
                </div>

                <div className="flex items-center justify-between sm:justify-end gap-3 shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100 dark:border-slate-800">
                  <span className="text-base font-bold font-mono tabular-nums text-slate-900 dark:text-white">
                    {formatCredits(tx.credits, creditFormat)} cr
                  </span>

                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      title={`Duplicate ${tx.foodName} for today`}
                      aria-label={`Duplicate ${tx.foodName}`}
                      onClick={() => onDuplicateTransaction(tx)}
                      className="p-2 rounded-lg text-slate-400 hover:text-emerald-600 dark:hover:text-emerald-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                    >
                      <Copy className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      aria-label={`Edit ${tx.foodName}`}
                      onClick={() => onEditTransaction(tx)}
                      className="p-2 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      aria-label={`Delete ${tx.foodName}`}
                      onClick={() => onDeleteTransaction(tx.id)}
                      className="p-2 rounded-lg text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};
