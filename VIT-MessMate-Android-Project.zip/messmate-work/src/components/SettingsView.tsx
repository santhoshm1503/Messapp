import React, { useRef, useState } from 'react';
import {
  AppSettings,
  BillingCycle,
  FoodPreset,
  MealTransaction,
} from '../types/mess';
import {
  calculateCycleEndDate,
  formatCredits,
  roundCredits,
  toLocalDateString,
} from '../utils/calculations';
import { PWAInstallButton } from './PWAInstallPrompt';
import {
  Archive,
  Bell,
  Check,
  Database,
  Download,
  FileSpreadsheet,
  FileText,
  Moon,
  RefreshCw,
  RotateCcw,
  Save,
  Sun,
  Upload,
} from 'lucide-react';

interface SettingsViewProps {
  cycle: BillingCycle;
  cycles: BillingCycle[];
  transactions: MealTransaction[];
  settings: AppSettings;
  presets: FoodPreset[];
  onUpdateCycle: (updated: BillingCycle) => void;
  onStartNewCycle: (params: {
    name: string;
    dailyReference: number;
    cycleDuration: number;
    monthlyBudget: number;
    startDate: string;
    endDate: string;
  }) => void;
  onSwitchActiveCycle: (cycleId: string) => void;
  onResetCurrentCycleTransactions: () => void;
  onUpdateSettings: (patch: Partial<AppSettings>) => void;
  onExportCSV: () => void;
  onExportMonthlyReport: () => void;
  onDownloadJSONBackup: () => void;
  onRestoreJSONBackup: (data: {
    cycles: BillingCycle[];
    transactions: MealTransaction[];
    settings: AppSettings;
    presets?: FoodPreset[];
  }) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  cycle,
  cycles,
  transactions,
  settings,
  onUpdateCycle,
  onStartNewCycle,
  onSwitchActiveCycle,
  onResetCurrentCycleTransactions,
  onUpdateSettings,
  onExportCSV,
  onExportMonthlyReport,
  onDownloadJSONBackup,
  onRestoreJSONBackup,
}) => {
  const [cycleName, setCycleName] = useState(cycle.name);
  const [dailyRef, setDailyRef] = useState(String(cycle.dailyReference));
  const [duration, setDuration] = useState(String(cycle.cycleDuration));
  const [monthlyBudget, setMonthlyBudget] = useState(String(cycle.monthlyBudget));
  const [startDate, setStartDate] = useState(cycle.startDate);
  const [endDate, setEndDate] = useState(cycle.endDate);
  const [statusToast, setStatusToast] = useState<string | null>(null);
  const [errorToast, setErrorToast] = useState<string | null>(null);

  // Rollover / Reset Confirmation Modal states
  const [showRolloverModal, setShowRolloverModal] = useState(false);
  const [showResetConfirmModal, setShowResetConfirmModal] = useState(false);
  const [newCycleStart, setNewCycleStart] = useState(toLocalDateString());
  const [newCycleDuration, setNewCycleDuration] = useState('30');
  const [newCycleDailyRef, setNewCycleDailyRef] = useState('288');

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const showSuccess = (msg: string) => {
    setStatusToast(msg);
    setErrorToast(null);
    setTimeout(() => setStatusToast(null), 4000);
  };

  // Auto-recalculate budget and end date when daily reference or duration changes
  const handleDailyRefChange = (val: string) => {
    setDailyRef(val);
    const r = parseFloat(val);
    const d = parseInt(duration, 10);
    if (Number.isFinite(r) && r > 0 && Number.isFinite(d) && d > 0) {
      setMonthlyBudget(String(roundCredits(r * d)));
    }
  };

  const handleDurationChange = (val: string) => {
    setDuration(val);
    const r = parseFloat(dailyRef);
    const d = parseInt(val, 10);
    if (Number.isFinite(d) && d > 0) {
      if (Number.isFinite(r) && r > 0) {
        setMonthlyBudget(String(roundCredits(r * d)));
      }
      if (startDate) {
        setEndDate(calculateCycleEndDate(startDate, d));
      }
    }
  };

  const handleStartDateChange = (val: string) => {
    setStartDate(val);
    const d = parseInt(duration, 10);
    if (val && Number.isFinite(d) && d > 0) {
      setEndDate(calculateCycleEndDate(val, d));
    }
  };

  const handleSaveCycleConfig = (e: React.FormEvent) => {
    e.preventDefault();
    const r = parseFloat(dailyRef);
    const d = parseInt(duration, 10);
    const b = parseFloat(monthlyBudget);

    if (!Number.isFinite(r) || r <= 0) {
      setErrorToast('Daily reference credits must be greater than 0.');
      return;
    }
    if (!Number.isFinite(d) || d < 1 || d > 365) {
      setErrorToast('Cycle duration must be between 1 and 365 days.');
      return;
    }
    if (!Number.isFinite(b) || b <= 0) {
      setErrorToast('Monthly budget must be greater than 0.');
      return;
    }

    onUpdateCycle({
      ...cycle,
      name: cycleName.trim() || `Cycle (${startDate} to ${endDate})`,
      dailyReference: roundCredits(r),
      cycleDuration: d,
      monthlyBudget: roundCredits(b),
      startDate,
      endDate,
    });
    showSuccess('Billing cycle configuration updated and monthly budget recalculated.');
  };

  const handleConfirmRollover = (e: React.FormEvent) => {
    e.preventDefault();
    const r = parseFloat(newCycleDailyRef) || 288;
    const d = parseInt(newCycleDuration, 10) || 30;
    const calcEnd = calculateCycleEndDate(newCycleStart, d);
    const budget = roundCredits(r * d);

    onStartNewCycle({
      name: `Cycle (${newCycleStart} to ${calcEnd})`,
      dailyReference: r,
      cycleDuration: d,
      monthlyBudget: budget,
      startDate: newCycleStart,
      endDate: calcEnd,
    });
    setShowRolloverModal(false);
    showSuccess(
      `Started new billing cycle (${newCycleStart} to ${calcEnd}). Previous cycle preserved in history.`
    );
  };

  const handleFileRestore = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result));
        if (
          !parsed ||
          !Array.isArray(parsed.cycles) ||
          !Array.isArray(parsed.transactions)
        ) {
          setErrorToast('Invalid backup JSON file structure.');
          return;
        }
        onRestoreJSONBackup(parsed);
        showSuccess(
          `Restored ${parsed.transactions.length} transactions across ${parsed.cycles.length} billing cycles.`
        );
      } catch {
        setErrorToast('Failed to parse JSON backup file.');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
            Settings & Cycle Configuration
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Customize your VIT paid-mess credit budget, manage billing cycles, configure alerts, and export backups.
          </p>
        </div>
        <PWAInstallButton variant="card" />
      </div>

      {statusToast && (
        <div
          role="status"
          className="rounded-xl border border-emerald-500/40 bg-emerald-500/10 px-4 py-3 text-xs font-semibold text-emerald-800 dark:text-emerald-300 flex items-center gap-2"
        >
          <Check className="w-4 h-4 shrink-0" />
          <span>{statusToast}</span>
        </div>
      )}

      {errorToast && (
        <div
          role="alert"
          className="rounded-xl border border-rose-500/40 bg-rose-500/10 px-4 py-3 text-xs font-semibold text-rose-700 dark:text-rose-300"
        >
          {errorToast}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left 7 Cols: Cycle Configuration + Multi-Cycle Rollover & History */}
        <div className="lg:col-span-7 space-y-6">
          {/* 1. Core Credit System Configuration */}
          <form
            onSubmit={handleSaveCycleConfig}
            className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111C33] p-5 sm:p-6 space-y-4"
          >
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                Current Billing Cycle Parameters
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Default VIT allocation is 288 credits/day × 30 days = 8,640 monthly credits. Customize any field below.
              </p>
            </div>

            <div>
              <label
                htmlFor="settings-cycle-name"
                className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
              >
                Cycle Label
              </label>
              <input
                id="settings-cycle-name"
                type="text"
                value={cycleName}
                onChange={(e) => setCycleName(e.target.value)}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 px-3.5 py-2 text-xs text-slate-900 dark:text-white"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
              <div>
                <label
                  htmlFor="settings-daily-ref"
                  className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
                >
                  Daily Reference Credits
                </label>
                <input
                  id="settings-daily-ref"
                  type="number"
                  step="any"
                  min="1"
                  value={dailyRef}
                  onChange={(e) => handleDailyRefChange(e.target.value)}
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 px-3.5 py-2 text-xs font-mono font-bold text-slate-900 dark:text-white tabular-nums"
                />
              </div>

              <div>
                <label
                  htmlFor="settings-cycle-duration"
                  className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
                >
                  Cycle Duration (Days)
                </label>
                <input
                  id="settings-cycle-duration"
                  type="number"
                  min="1"
                  max="365"
                  value={duration}
                  onChange={(e) => handleDurationChange(e.target.value)}
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 px-3.5 py-2 text-xs font-mono font-bold text-slate-900 dark:text-white tabular-nums"
                />
              </div>

              <div>
                <label
                  htmlFor="settings-monthly-budget"
                  className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
                >
                  Monthly Starting Credits
                </label>
                <input
                  id="settings-monthly-budget"
                  type="number"
                  step="any"
                  min="1"
                  value={monthlyBudget}
                  onChange={(e) => setMonthlyBudget(e.target.value)}
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 px-3.5 py-2 text-xs font-mono font-bold text-emerald-600 dark:text-emerald-400 tabular-nums"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div>
                <label
                  htmlFor="settings-start-date"
                  className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
                >
                  Cycle Start Date
                </label>
                <input
                  id="settings-start-date"
                  type="date"
                  value={startDate}
                  onChange={(e) => handleStartDateChange(e.target.value)}
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 px-3.5 py-2 text-xs font-mono text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label
                  htmlFor="settings-end-date"
                  className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
                >
                  Cycle End Date
                </label>
                <input
                  id="settings-end-date"
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 px-3.5 py-2 text-xs font-mono text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3">
              <span className="text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums">
                Auto-calc: {dailyRef || 0} × {duration || 0} ={' '}
                {formatCredits((parseFloat(dailyRef) || 0) * (parseInt(duration, 10) || 0))} cr
              </span>
              <button
                type="submit"
                className="inline-flex items-center gap-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 px-5 py-2.5 text-xs font-bold text-white transition-colors cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>Save Cycle Settings</span>
              </button>
            </div>
          </form>

          {/* 2. Billing Cycle Rollover & Multi-Cycle History */}
          <section
            aria-label="Billing Cycle History and Rollover"
            className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111C33] p-5 sm:p-6 space-y-4"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Archive className="w-4 h-4 text-emerald-500" />
                  <span>Billing Cycles & Monthly Rollover</span>
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Starting a new billing cycle archives your current cycle so historical records are never lost.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowRolloverModal(true)}
                  className="inline-flex items-center gap-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 px-3.5 py-2 text-xs font-semibold text-white transition-colors cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Start New Billing Cycle</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowResetConfirmModal(true)}
                  className="inline-flex items-center gap-1.5 rounded-xl border border-rose-500/40 bg-rose-500/10 hover:bg-rose-500/20 px-3.5 py-2 text-xs font-semibold text-rose-600 dark:text-rose-400 transition-colors cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Reset Current Cycle</span>
                </button>
              </div>
            </div>

            <div className="divide-y divide-slate-100 dark:divide-slate-800 border-t border-slate-100 dark:border-slate-800 pt-2">
              {cycles.map((c) => {
                const cTx = transactions.filter((t) => t.cycleId === c.id);
                const cUsed = roundCredits(cTx.reduce((s, t) => s + t.credits, 0));
                const isSelected = c.id === cycle.id;
                return (
                  <div
                    key={c.id}
                    className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div>
                      <div className="text-xs font-bold text-slate-900 dark:text-white">
                        {c.name}{' '}
                        <span className="font-normal text-slate-500 dark:text-slate-400">
                          · {c.isArchived ? 'Archived' : 'Active'}
                        </span>
                      </div>
                      <div className="text-[11px] font-mono tabular-nums text-slate-500 dark:text-slate-400 mt-0.5">
                        {c.startDate} to {c.endDate} · Used {formatCredits(cUsed, settings.creditDisplayFormat)} / {formatCredits(c.monthlyBudget, settings.creditDisplayFormat)} cr ({cTx.length} meals)
                      </div>
                    </div>

                    {isSelected ? (
                      <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 font-mono">
                        Viewing Now
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={() => onSwitchActiveCycle(c.id)}
                        className="self-start sm:self-auto px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                      >
                        Switch to Cycle
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </section>
        </div>

        {/* Right 5 Cols: Theme & Display, Alerts, and Data Export/Backup */}
        <div className="lg:col-span-5 space-y-6">
          {/* Theme, Display & Alerts */}
          <section
            aria-label="Theme, Display, and Notifications"
            className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111C33] p-5 sm:p-6 space-y-4"
          >
            <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Bell className="w-4 h-4 text-emerald-500" />
              <span>Appearance, Display & Alerts</span>
            </h2>

            {/* Theme Toggle */}
            <div className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-slate-800">
              <div>
                <div className="text-xs font-semibold text-slate-900 dark:text-white">
                  Interface Theme
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400">
                  Switch between dark navy and crisp light mode
                </div>
              </div>
              <button
                type="button"
                onClick={() =>
                  onUpdateSettings({
                    theme: settings.theme === 'dark' ? 'light' : 'dark',
                  })
                }
                className="inline-flex items-center gap-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3.5 py-2 text-xs font-semibold text-slate-800 dark:text-slate-200 cursor-pointer"
              >
                {settings.theme === 'dark' ? (
                  <>
                    <Moon className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Dark Theme</span>
                  </>
                ) : (
                  <>
                    <Sun className="w-3.5 h-3.5 text-amber-500" />
                    <span>Light Theme</span>
                  </>
                )}
              </button>
            </div>

            {/* Credit Number Format */}
            <div className="flex items-center justify-between py-2 border-b border-slate-100 dark:border-slate-800">
              <div>
                <div className="text-xs font-semibold text-slate-900 dark:text-white">
                  Credit Number Formatting
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400">
                  Integer preferred (288) or fixed 2 decimals (288.00)
                </div>
              </div>
              <select
                aria-label="Credit display format"
                value={settings.creditDisplayFormat}
                onChange={(e) =>
                  onUpdateSettings({
                    creditDisplayFormat: e.target.value as AppSettings['creditDisplayFormat'],
                  })
                }
                className="rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 px-3 py-1.5 text-xs font-mono text-slate-900 dark:text-white"
              >
                <option value="integer-preferred">Smart (288 / 286.67)</option>
                <option value="two-decimals">2 Decimals (288.00)</option>
              </select>
            </div>

            {/* Overspending Alerts & Low Balance Threshold */}
            <div className="space-y-3 pt-1">
              <label className="flex items-center justify-between text-xs cursor-pointer">
                <span className="font-semibold text-slate-800 dark:text-slate-200">
                  Overspending & Low Balance Alerts
                </span>
                <input
                  type="checkbox"
                  checked={settings.overspendingAlertEnabled}
                  onChange={(e) =>
                    onUpdateSettings({ overspendingAlertEnabled: e.target.checked })
                  }
                  className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                />
              </label>

              <div className="flex items-center justify-between gap-3">
                <label
                  htmlFor="settings-low-balance"
                  className="text-xs text-slate-600 dark:text-slate-400"
                >
                  Low balance alert threshold (credits):
                </label>
                <input
                  id="settings-low-balance"
                  type="number"
                  min="0"
                  step="100"
                  value={settings.lowBalanceAlertThreshold}
                  onChange={(e) =>
                    onUpdateSettings({
                      lowBalanceAlertThreshold: Math.max(0, parseInt(e.target.value, 10) || 0),
                    })
                  }
                  className="w-24 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 px-2.5 py-1.5 text-xs font-mono font-bold text-slate-900 dark:text-white tabular-nums"
                />
              </div>

              <div className="flex items-center justify-between gap-3 pt-2 border-t border-slate-100 dark:border-slate-800">
                <label className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings.dailyReminderEnabled}
                    onChange={(e) =>
                      onUpdateSettings({ dailyReminderEnabled: e.target.checked })
                    }
                    className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
                  />
                  <span>Daily Meal Logging Reminder</span>
                </label>
                <input
                  type="time"
                  aria-label="Daily reminder time"
                  value={settings.dailyReminderTime}
                  onChange={(e) =>
                    onUpdateSettings({ dailyReminderTime: e.target.value })
                  }
                  className="rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 px-2.5 py-1 text-xs font-mono text-slate-900 dark:text-white"
                />
              </div>
            </div>
          </section>

          {/* Data Export, Backup & Local-First IndexedDB Status */}
          <section
            aria-label="Data Storage, Export and Backup"
            className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111C33] p-5 sm:p-6 space-y-4"
          >
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Database className="w-4 h-4 text-emerald-500" />
                <span>Persistent Storage, Export & Backup</span>
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
                Storage Architecture: <strong>Local-First IndexedDB</strong> (`vit_messmate_db`). All transactions, cycles, and settings persist across page refreshes, browser restarts, and offline sessions. (Cloud sync is not configured).
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <button
                type="button"
                onClick={onExportCSV}
                className="flex items-center justify-center gap-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-800 py-2.5 px-3.5 text-xs font-semibold text-slate-800 dark:text-slate-200 transition-colors cursor-pointer"
              >
                <FileSpreadsheet className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>Export CSV</span>
              </button>

              <button
                type="button"
                onClick={onExportMonthlyReport}
                className="flex items-center justify-center gap-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-800 py-2.5 px-3.5 text-xs font-semibold text-slate-800 dark:text-slate-200 transition-colors cursor-pointer"
              >
                <FileText className="w-4 h-4 text-sky-500 shrink-0" />
                <span>Export Monthly Report</span>
              </button>

              <button
                type="button"
                onClick={onDownloadJSONBackup}
                className="flex items-center justify-center gap-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-800 py-2.5 px-3.5 text-xs font-semibold text-slate-800 dark:text-slate-200 transition-colors cursor-pointer"
              >
                <Download className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>Download JSON Backup</span>
              </button>

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center justify-center gap-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-800 py-2.5 px-3.5 text-xs font-semibold text-slate-800 dark:text-slate-200 transition-colors cursor-pointer"
              >
                <Upload className="w-4 h-4 text-amber-500 shrink-0" />
                <span>Restore JSON Backup</span>
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept="application/json,.json"
                onChange={handleFileRestore}
                className="hidden"
              />
            </div>
          </section>
        </div>
      </div>

      {/* Modal 1: Start New Billing Cycle (Rollover) */}
      {showRolloverModal && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="rollover-modal-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4"
        >
          <form
            onSubmit={handleConfirmRollover}
            className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-xl space-y-4"
          >
            <h3
              id="rollover-modal-title"
              className="text-base font-bold text-slate-900 dark:text-white"
            >
              Start New Billing Cycle (Rollover)
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              Your current cycle (<strong>{cycle.name}</strong>) and all its meal records will be safely archived in your Billing Cycle History.
            </p>
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  New Cycle Start Date
                </label>
                <input
                  type="date"
                  value={newCycleStart}
                  onChange={(e) => setNewCycleStart(e.target.value)}
                  required
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-2 text-xs font-mono text-slate-900 dark:text-white"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Daily Reference (cr)
                  </label>
                  <input
                    type="number"
                    value={newCycleDailyRef}
                    onChange={(e) => setNewCycleDailyRef(e.target.value)}
                    required
                    className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-2 text-xs font-mono text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Duration (Days)
                  </label>
                  <input
                    type="number"
                    value={newCycleDuration}
                    onChange={(e) => setNewCycleDuration(e.target.value)}
                    required
                    className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 px-3 py-2 text-xs font-mono text-slate-900 dark:text-white"
                  />
                </div>
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-3">
              <button
                type="button"
                onClick={() => setShowRolloverModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs font-bold text-white cursor-pointer"
              >
                Archive Current & Start New Cycle
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Modal 2: Reset Current Cycle Confirmation */}
      {showResetConfirmModal && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="reset-modal-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4"
        >
          <div className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 shadow-xl space-y-4">
            <h3
              id="reset-modal-title"
              className="text-base font-bold text-slate-900 dark:text-white"
            >
              Reset Current Cycle Transactions?
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              This will clear all recorded meals in <strong>{cycle.name}</strong> and reset your used credits for this cycle to 0. Archived previous cycles will not be affected.
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowResetConfirmModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  onResetCurrentCycleTransactions();
                  setShowResetConfirmModal(false);
                  showSuccess('Current cycle transactions have been reset to 0 used credits.');
                }}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-xs font-bold text-white cursor-pointer"
              >
                Confirm Reset to 0
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
