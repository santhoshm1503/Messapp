import React, { useState } from 'react';
import {
  FoodPreset,
  MEAL_CATEGORIES,
  MealCategory,
  MealTransaction,
} from '../types/mess';
import {
  formatCredits,
  isValidCreditAmount,
  roundCredits,
  toLocalDateString,
  toLocalTimeString,
} from '../utils/calculations';
import {
  BookmarkPlus,
  Check,
  Copy,
  Layers,
  Plus,
  Trash2,
  Utensils,
  Zap,
} from 'lucide-react';

interface DraftFoodItem {
  key: string;
  foodName: string;
  category: MealCategory;
  unitCredits: string;
  quantity: string;
  notes: string;
  tags: string;
}

interface AddMealViewProps {
  prefillDate?: string;
  presets: FoodPreset[];
  lastMeal?: MealTransaction;
  creditFormat: 'integer-preferred' | 'two-decimals';
  onAddMeals: (
    meals: Array<{
      category: MealCategory;
      foodName: string;
      credits: number;
      unitCredits: number;
      quantity: number;
      date: string;
      time: string;
      notes?: string;
      tags?: string[];
    }>
  ) => void;
  onAddPreset: (preset: Omit<FoodPreset, 'id'>) => void;
  onDeletePreset: (id: string) => void;
  onDuplicateLastMeal: () => void;
}

export const AddMealView: React.FC<AddMealViewProps> = ({
  prefillDate,
  presets,
  lastMeal,
  creditFormat,
  onAddMeals,
  onAddPreset,
  onDeletePreset,
  onDuplicateLastMeal,
}) => {
  const [date, setDate] = useState<string>(prefillDate || toLocalDateString());
  const [time, setTime] = useState<string>(toLocalTimeString());
  const [saveAsPreset, setSaveAsPreset] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const [items, setItems] = useState<DraftFoodItem[]>([
    {
      key: 'item-1',
      foodName: '',
      category: 'Lunch',
      unitCredits: '',
      quantity: '1',
      notes: '',
      tags: '',
    },
  ]);

  // Custom preset form state
  const [showPresetForm, setShowPresetForm] = useState(false);
  const [newPresetName, setNewPresetName] = useState('');
  const [newPresetCategory, setNewPresetCategory] = useState<MealCategory>('Breakfast');
  const [newPresetCredits, setNewPresetCredits] = useState('');

  const updateItem = (key: string, patch: Partial<DraftFoodItem>) => {
    setItems((prev) => prev.map((it) => (it.key === key ? { ...it, ...patch } : it)));
    setErrorMessage(null);
  };

  const addAnotherItemRow = () => {
    setItems((prev) => [
      ...prev,
      {
        key: `item-${Date.now()}-${prev.length + 1}`,
        foodName: '',
        category: prev[prev.length - 1]?.category || 'Lunch',
        unitCredits: '',
        quantity: '1',
        notes: '',
        tags: '',
      },
    ]);
  };

  const removeItemRow = (key: string) => {
    if (items.length <= 1) return;
    setItems((prev) => prev.filter((it) => it.key !== key));
  };

  const prefillFromPreset = (preset: FoodPreset) => {
    setItems((prev) => {
      const firstEmptyIdx = prev.findIndex(
        (it) => !it.foodName.trim() && !it.unitCredits.trim()
      );
      if (firstEmptyIdx !== -1) {
        return prev.map((it, idx) =>
          idx === firstEmptyIdx
            ? {
                ...it,
                foodName: preset.foodName,
                category: preset.category,
                unitCredits: String(preset.credits),
                quantity: '1',
                tags: (preset.tags || []).join(', '),
              }
            : it
        );
      }
      return [
        ...prev,
        {
          key: `item-${Date.now()}`,
          foodName: preset.foodName,
          category: preset.category,
          unitCredits: String(preset.credits),
          quantity: '1',
          notes: '',
          tags: (preset.tags || []).join(', '),
        },
      ];
    });
    setErrorMessage(null);
  };

  const quickLogImmediately = (preset: FoodPreset) => {
    onAddMeals([
      {
        category: preset.category,
        foodName: preset.foodName,
        credits: preset.credits,
        unitCredits: preset.credits,
        quantity: 1,
        date,
        time: toLocalTimeString(),
        tags: preset.tags,
      },
    ]);
    setSuccessMessage(
      `Recorded "${preset.foodName}" (${formatCredits(preset.credits, creditFormat)} cr) for ${date}.`
    );
    setTimeout(() => setSuccessMessage(null), 3500);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!date) {
      setErrorMessage('Please select a valid date for the meal entry.');
      return;
    }

    const validatedMeals: Array<{
      category: MealCategory;
      foodName: string;
      credits: number;
      unitCredits: number;
      quantity: number;
      date: string;
      time: string;
      notes?: string;
      tags?: string[];
    }> = [];

    for (let i = 0; i < items.length; i++) {
      const row = items[i];
      const name = row.foodName.trim();
      const unitVal = parseFloat(row.unitCredits);
      const qtyVal = parseFloat(row.quantity || '1');

      if (!name) {
        setErrorMessage(`Please enter a food item name for item #${i + 1}.`);
        return;
      }
      if (!isValidCreditAmount(unitVal)) {
        setErrorMessage(
          `Please enter a valid positive credit amount greater than 0 for "${name}".`
        );
        return;
      }
      if (!Number.isFinite(qtyVal) || qtyVal <= 0) {
        setErrorMessage(`Quantity for "${name}" must be at least 1.`);
        return;
      }

      const totalItemCredits = roundCredits(unitVal * qtyVal);
      const parsedTags = row.tags
        .split(',')
        .map((t) => t.trim())
        .filter(Boolean);

      validatedMeals.push({
        category: row.category,
        foodName: name,
        credits: totalItemCredits,
        unitCredits: roundCredits(unitVal),
        quantity: qtyVal,
        date,
        time: time || '12:00',
        notes: row.notes.trim() || undefined,
        tags: parsedTags.length > 0 ? parsedTags : undefined,
      });

      if (saveAsPreset) {
        onAddPreset({
          foodName: name,
          category: row.category,
          credits: roundCredits(unitVal),
          tags: parsedTags.length > 0 ? parsedTags : undefined,
        });
      }
    }

    onAddMeals(validatedMeals);
  };

  const handleCreateCustomPreset = (e: React.FormEvent) => {
    e.preventDefault();
    const creditVal = parseFloat(newPresetCredits);
    if (!newPresetName.trim() || !isValidCreditAmount(creditVal)) {
      return;
    }
    onAddPreset({
      foodName: newPresetName.trim(),
      category: newPresetCategory,
      credits: roundCredits(creditVal),
    });
    setNewPresetName('');
    setNewPresetCredits('');
    setShowPresetForm(false);
  };

  const batchTotalCredits = roundCredits(
    items.reduce((sum, it) => {
      const u = parseFloat(it.unitCredits);
      const q = parseFloat(it.quantity || '1');
      if (Number.isFinite(u) && u > 0 && Number.isFinite(q) && q > 0) {
        return sum + u * q;
      }
      return sum;
    }, 0)
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
            Record Mess Meal
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Enter actual VIT paid-mess credits for one or multiple food items. No daily spending limit is enforced.
          </p>
        </div>

        {lastMeal && (
          <button
            type="button"
            onClick={onDuplicateLastMeal}
            className="inline-flex items-center gap-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#111C33] hover:bg-slate-50 dark:hover:bg-slate-800 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 transition-colors self-start sm:self-auto cursor-pointer"
          >
            <Copy className="w-3.5 h-3.5 text-emerald-500" />
            <span>
              Duplicate Last: {lastMeal.foodName} ({formatCredits(lastMeal.credits, creditFormat)} cr)
            </span>
          </button>
        )}
      </div>

      {successMessage && (
        <div
          role="status"
          className="rounded-xl border border-emerald-500/40 bg-emerald-500/10 px-4 py-3 text-xs font-semibold text-emerald-800 dark:text-emerald-300 flex items-center gap-2"
        >
          <Check className="w-4 h-4 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {errorMessage && (
        <div
          role="alert"
          className="rounded-xl border border-rose-500/40 bg-rose-500/10 px-4 py-3 text-xs font-semibold text-rose-700 dark:text-rose-300"
        >
          {errorMessage}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Main Meal Entry Form */}
        <form
          onSubmit={handleSubmit}
          className="lg:col-span-8 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111C33] p-5 sm:p-6 space-y-6"
        >
          {/* Shared Date & Time Selector */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pb-5 border-b border-slate-100 dark:border-slate-800">
            <div>
              <label
                htmlFor="meal-entry-date"
                className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
              >
                Meal Date (Today or Previous Date)
              </label>
              <input
                id="meal-entry-date"
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                required
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 px-3.5 py-2.5 text-xs font-mono text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
            <div>
              <label
                htmlFor="meal-entry-time"
                className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
              >
                Meal Time
              </label>
              <input
                id="meal-entry-time"
                type="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                required
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 px-3.5 py-2.5 text-xs font-mono text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          {/* Food Items List (Supports 1 or Multiple Items) */}
          <div className="space-y-5">
            {items.map((item, idx) => (
              <div
                key={item.key}
                className="space-y-4 pb-5 border-b border-slate-100 dark:border-slate-800 last:border-b-0 last:pb-0"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                    <Utensils className="w-3.5 h-3.5 text-emerald-500" />
                    <span>Food Item #{idx + 1}</span>
                  </span>
                  {items.length > 1 && (
                    <button
                      type="button"
                      onClick={() => removeItemRow(item.key)}
                      className="text-xs font-semibold text-rose-600 dark:text-rose-400 hover:underline inline-flex items-center gap-1 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Remove Item</span>
                    </button>
                  )}
                </div>

                {/* Category Selector Buttons */}
                <div>
                  <span className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">
                    Meal Category
                  </span>
                  <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                    {MEAL_CATEGORIES.map((cat) => (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => updateItem(item.key, { category: cat })}
                        className={`py-2 px-2.5 rounded-xl text-xs font-semibold border transition-colors cursor-pointer ${
                          item.category === cat
                            ? 'border-emerald-500 bg-emerald-500/15 text-emerald-700 dark:text-emerald-300'
                            : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/60 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Food Name, Credit Cost, Quantity */}
                <div className="grid grid-cols-1 sm:grid-cols-12 gap-3.5">
                  <div className="sm:col-span-6">
                    <label
                      htmlFor={`food-name-${item.key}`}
                      className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
                    >
                      Food Item Name *
                    </label>
                    <input
                      id={`food-name-${item.key}`}
                      type="text"
                      placeholder="e.g. Masala Dosa, Paneer Butter Masala, Samosa"
                      value={item.foodName}
                      onChange={(e) => updateItem(item.key, { foodName: e.target.value })}
                      required
                      className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 px-3.5 py-2.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>

                  <div className="sm:col-span-4">
                    <label
                      htmlFor={`food-credits-${item.key}`}
                      className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
                    >
                      Credit Cost (per unit) *
                    </label>
                    <input
                      id={`food-credits-${item.key}`}
                      type="number"
                      step="any"
                      min="0.01"
                      placeholder="e.g. 75"
                      value={item.unitCredits}
                      onChange={(e) => updateItem(item.key, { unitCredits: e.target.value })}
                      required
                      className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 px-3.5 py-2.5 text-xs font-mono font-bold text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 tabular-nums"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label
                      htmlFor={`food-qty-${item.key}`}
                      className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
                    >
                      Quantity
                    </label>
                    <input
                      id={`food-qty-${item.key}`}
                      type="number"
                      step="1"
                      min="1"
                      value={item.quantity}
                      onChange={(e) => updateItem(item.key, { quantity: e.target.value })}
                      className="w-full rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 px-3 py-2.5 text-xs font-mono text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500 tabular-nums"
                    />
                  </div>
                </div>

                {/* Optional Notes & Tags */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label
                      htmlFor={`food-notes-${item.key}`}
                      className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1"
                    >
                      Notes (Optional)
                    </label>
                    <input
                      id={`food-notes-${item.key}`}
                      type="text"
                      placeholder="e.g. Extra roast, shared with roommate"
                      value={item.notes}
                      onChange={(e) => updateItem(item.key, { notes: e.target.value })}
                      className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/60 px-3.5 py-2 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                  <div>
                    <label
                      htmlFor={`food-tags-${item.key}`}
                      className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1"
                    >
                      Tags (Optional, comma-separated)
                    </label>
                    <input
                      id={`food-tags-${item.key}`}
                      type="text"
                      placeholder="e.g. South Indian, Special, Protein"
                      value={item.tags}
                      onChange={(e) => updateItem(item.key, { tags: e.target.value })}
                      className="w-full rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/60 px-3.5 py-2 text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Add Another Food Item Button + Save as Preset Checkbox */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={addAnotherItemRow}
              className="inline-flex items-center gap-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/70 hover:bg-slate-100 dark:hover:bg-slate-800 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 transition-colors self-start cursor-pointer"
            >
              <Layers className="w-3.5 h-3.5 text-emerald-500" />
              <span>+ Add Another Food Item to This Meal</span>
            </button>

            <label className="inline-flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={saveAsPreset}
                onChange={(e) => setSaveAsPreset(e.target.checked)}
                className="rounded border-slate-300 text-emerald-600 focus:ring-emerald-500"
              />
              <span>Save item(s) to Custom Quick-Add Presets</span>
            </label>
          </div>

          {/* Submit Footer */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-4 border-t border-slate-200 dark:border-slate-800">
            <div className="font-mono tabular-nums">
              <span className="text-xs text-slate-500 dark:text-slate-400 block font-sans">
                Total Entry Credits ({items.length} item{items.length === 1 ? '' : 's'})
              </span>
              <span className="text-xl font-bold text-emerald-600 dark:text-emerald-400">
                {formatCredits(batchTotalCredits, creditFormat)} credits
              </span>
            </div>

            <button
              type="submit"
              className="inline-flex items-center justify-center gap-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 px-6 py-3 text-sm font-bold text-white shadow-xs transition-colors cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>
                Save Meal {items.length > 1 ? `(${items.length} Items)` : 'Entry'}
              </span>
            </button>
          </div>
        </form>

        {/* Right Column: Common Meal Examples & Custom Presets */}
        <aside
          aria-label="Quick Add Presets"
          className="lg:col-span-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111C33] p-5 space-y-4"
        >
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                <Zap className="w-4 h-4 text-emerald-500" />
                <span>Quick-Add & Food Presets</span>
              </h2>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                Example prices — prefill the form to edit credits or log in 1 tap.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setShowPresetForm((v) => !v)}
              className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:underline cursor-pointer"
            >
              <BookmarkPlus className="w-3.5 h-3.5" />
              <span>New Preset</span>
            </button>
          </div>

          {showPresetForm && (
            <form
              onSubmit={handleCreateCustomPreset}
              className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/70 p-3.5 space-y-3"
            >
              <div className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                Create Custom Food Preset
              </div>
              <input
                type="text"
                placeholder="Preset Food Name"
                value={newPresetName}
                onChange={(e) => setNewPresetName(e.target.value)}
                required
                className="w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-1.5 text-xs text-slate-900 dark:text-white"
              />
              <div className="grid grid-cols-2 gap-2">
                <select
                  aria-label="Preset category"
                  value={newPresetCategory}
                  onChange={(e) => setNewPresetCategory(e.target.value as MealCategory)}
                  className="rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-2.5 py-1.5 text-xs text-slate-900 dark:text-white"
                >
                  {MEAL_CATEGORIES.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
                <input
                  type="number"
                  step="any"
                  min="1"
                  placeholder="Credits (e.g. 90)"
                  value={newPresetCredits}
                  onChange={(e) => setNewPresetCredits(e.target.value)}
                  required
                  className="rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 px-2.5 py-1.5 text-xs font-mono text-slate-900 dark:text-white"
                />
              </div>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowPresetForm(false)}
                  className="px-3 py-1 text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-emerald-600 px-3 py-1 text-xs font-semibold text-white hover:bg-emerald-500 cursor-pointer"
                >
                  Save Preset
                </button>
              </div>
            </form>
          )}

          <div className="divide-y divide-slate-100 dark:divide-slate-800/80">
            {presets.map((preset) => (
              <div
                key={preset.id}
                className="py-2.5 flex items-center justify-between gap-2"
              >
                <div className="min-w-0">
                  <div className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                    {preset.foodName}
                  </div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400">
                    {preset.category} ·{' '}
                    <span className="font-mono font-semibold text-emerald-600 dark:text-emerald-400 tabular-nums">
                      {formatCredits(preset.credits, creditFormat)} cr
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() => prefillFromPreset(preset)}
                    className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-[11px] font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                  >
                    Fill Form
                  </button>
                  <button
                    type="button"
                    onClick={() => quickLogImmediately(preset)}
                    className="px-2.5 py-1.5 rounded-lg bg-emerald-600/15 text-[11px] font-semibold text-emerald-700 dark:text-emerald-300 hover:bg-emerald-600 hover:text-white transition-colors cursor-pointer"
                  >
                    + Log
                  </button>
                  {!preset.id.startsWith('preset-bf-standard') &&
                    !preset.id.startsWith('preset-lunch-thali') &&
                    !preset.id.startsWith('preset-snacks-samosa') &&
                    !preset.id.startsWith('preset-dinner-combo') && (
                      <button
                        type="button"
                        aria-label={`Delete preset ${preset.foodName}`}
                        onClick={() => onDeletePreset(preset.id)}
                        className="p-1 text-slate-400 hover:text-rose-500 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                </div>
              </div>
            ))}
          </div>
        </aside>
      </div>
    </div>
  );
};
