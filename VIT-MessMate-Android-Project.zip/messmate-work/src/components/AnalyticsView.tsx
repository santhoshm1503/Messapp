import React, { useMemo, useState } from 'react';
import {
  BillingCycle,
  CycleMetrics,
  MEAL_CATEGORIES,
  MealCategory,
  MealTransaction,
  SmartInsight,
} from '../types/mess';
import {
  addDaysToDateString,
  diffCalendarDays,
  formatCredits,
  roundCredits,
  toLocalDateString,
} from '../utils/calculations';
import {
  BarChart3,
  Download,
  PieChart as PieChartIcon,
  TrendingDown,
  TrendingUp,
} from 'lucide-react';

interface AnalyticsViewProps {
  cycle: BillingCycle;
  metrics: CycleMetrics;
  transactions: MealTransaction[];
  insights: SmartInsight[];
  creditFormat: 'integer-preferred' | 'two-decimals';
  onExportMonthlyReport: () => void;
}

type RangeFilter = '7d' | '15d' | 'cycle' | 'custom';

const CATEGORY_COLORS: Record<MealCategory, string> = {
  Breakfast: '#10B981', // Emerald
  Lunch: '#0EA5E9', // Sky
  Snacks: '#F59E0B', // Amber
  Dinner: '#6366F1', // Indigo
  Beverages: '#EC4899', // Pink
  Other: '#94A3B8', // Slate
};

export const AnalyticsView: React.FC<AnalyticsViewProps> = ({
  cycle,
  metrics,
  transactions,
  insights,
  creditFormat,
  onExportMonthlyReport,
}) => {
  const todayStr = toLocalDateString();
  const [rangeFilter, setRangeFilter] = useState<RangeFilter>('cycle');
  const [customStart, setCustomStart] = useState<string>(cycle.startDate);
  const [customEnd, setCustomEnd] = useState<string>(todayStr);
  const [hoveredDayIndex, setHoveredDayIndex] = useState<number | null>(null);

  const { startDate, endDate } = useMemo(() => {
    if (rangeFilter === '7d') {
      return {
        startDate: addDaysToDateString(todayStr, -6),
        endDate: todayStr,
      };
    }
    if (rangeFilter === '15d') {
      return {
        startDate: addDaysToDateString(todayStr, -14),
        endDate: todayStr,
      };
    }
    if (rangeFilter === 'custom') {
      return {
        startDate: customStart <= customEnd ? customStart : customEnd,
        endDate: customEnd >= customStart ? customEnd : customStart,
      };
    }
    // For 'cycle', show from cycle start up to today (or cycle end if earlier/has transactions)
    const maxTxDate = transactions
      .filter((t) => t.cycleId === cycle.id)
      .reduce((max, t) => (t.date > max ? t.date : max), todayStr);
    const effectiveEnd =
      maxTxDate > cycle.endDate
        ? maxTxDate
        : todayStr < cycle.endDate && todayStr >= cycle.startDate
        ? todayStr
        : cycle.endDate;
    return {
      startDate: cycle.startDate,
      endDate: effectiveEnd < cycle.startDate ? cycle.endDate : effectiveEnd,
    };
  }, [rangeFilter, todayStr, customStart, customEnd, cycle, transactions]);

  const filteredTx = useMemo(() => {
    return transactions.filter((t) => {
      if (rangeFilter === 'cycle' && t.cycleId !== cycle.id) return false;
      return t.date >= startDate && t.date <= endDate;
    });
  }, [transactions, rangeFilter, cycle.id, startDate, endDate]);

  // Build daily series across [startDate..endDate]
  const dailySeries = useMemo(() => {
    const dayCount = Math.max(1, Math.min(90, diffCalendarDays(startDate, endDate) + 1));
    const map = new Map<string, { credits: number; meals: number }>();
    for (const tx of filteredTx) {
      const curr = map.get(tx.date) || { credits: 0, meals: 0 };
      curr.credits = roundCredits(curr.credits + tx.credits);
      curr.meals += 1;
      map.set(tx.date, curr);
    }

    const list: Array<{ date: string; label: string; credits: number; meals: number }> = [];
    for (let i = 0; i < dayCount; i++) {
      const d = addDaysToDateString(startDate, i);
      const entry = map.get(d) || { credits: 0, meals: 0 };
      list.push({
        date: d,
        label: d.slice(5),
        credits: entry.credits,
        meals: entry.meals,
      });
    }
    return list;
  }, [startDate, endDate, filteredTx]);

  // Analytics KPIs
  const kpiStats = useMemo(() => {
    const totalCredits = roundCredits(filteredTx.reduce((s, t) => s + t.credits, 0));
    const totalMeals = filteredTx.length;
    const avgMealCost = totalMeals > 0 ? roundCredits(totalCredits / totalMeals) : 0;

    const activeDays = dailySeries.filter((d) => d.meals > 0);
    const avgDailySpend =
      activeDays.length > 0 ? roundCredits(totalCredits / activeDays.length) : 0;

    const sortedActive = [...activeDays].sort((a, b) => b.credits - a.credits);
    const highestDay = sortedActive[0] || null;
    const lowestDay = sortedActive[sortedActive.length - 1] || null;

    return {
      totalCredits,
      totalMeals,
      avgMealCost,
      avgDailySpend,
      activeDaysCount: activeDays.length,
      highestDay,
      lowestDay,
    };
  }, [filteredTx, dailySeries]);

  // Category Breakdown
  const categoryBreakdown = useMemo(() => {
    const total = kpiStats.totalCredits;
    return MEAL_CATEGORIES.map((cat) => {
      const items = filteredTx.filter((t) => t.category === cat);
      const credits = roundCredits(items.reduce((s, t) => s + t.credits, 0));
      const pct = total > 0 ? roundCredits((credits / total) * 100) : 0;
      const avgCost = items.length > 0 ? roundCredits(credits / items.length) : 0;
      return {
        category: cat,
        credits,
        pct,
        count: items.length,
        avgCost,
        color: CATEGORY_COLORS[cat],
      };
    });
  }, [filteredTx, kpiStats.totalCredits]);

  // Weekly Spending Bar Chart Breakdown (7-day buckets from cycle.startDate)
  const weeklySummaries = useMemo(() => {
    const cycleTx = transactions.filter((t) => t.cycleId === cycle.id);
    const numWeeks = Math.ceil(cycle.cycleDuration / 7);
    const weeks: Array<{
      weekNum: number;
      rangeLabel: string;
      credits: number;
      meals: number;
      reference: number;
    }> = [];

    for (let w = 0; w < numWeeks; w++) {
      const wStartOffset = w * 7;
      const wDays = Math.min(7, cycle.cycleDuration - wStartOffset);
      const wStart = addDaysToDateString(cycle.startDate, wStartOffset);
      const wEnd = addDaysToDateString(wStart, wDays - 1);
      const wTx = cycleTx.filter((t) => t.date >= wStart && t.date <= wEnd);
      const credits = roundCredits(wTx.reduce((s, t) => s + t.credits, 0));
      weeks.push({
        weekNum: w + 1,
        rangeLabel: `${wStart.slice(5)} to ${wEnd.slice(5)}`,
        credits,
        meals: wTx.length,
        reference: roundCredits(cycle.dailyReference * wDays),
      });
    }
    return weeks;
  }, [transactions, cycle]);

  // SVG Line Chart geometry
  const chartW = 720;
  const chartH = 220;
  const padL = 44;
  const padR = 20;
  const padT = 20;
  const padB = 34;
  const plotW = chartW - padL - padR;
  const plotH = chartH - padT - padB;

  const maxDailyY = Math.max(
    cycle.dailyReference * 1.4,
    ...dailySeries.map((d) => d.credits),
    400
  );

  const linePoints = dailySeries.map((d, idx) => {
    const x =
      dailySeries.length === 1
        ? padL + plotW / 2
        : padL + (idx / (dailySeries.length - 1)) * plotW;
    const y = padT + plotH - (d.credits / maxDailyY) * plotH;
    return { x, y, ...d };
  });

  const polylineStr = linePoints.map((p) => `${p.x},${p.y}`).join(' ');
  const refLineY = padT + plotH - (cycle.dailyReference / maxDailyY) * plotH;

  // Donut Chart geometry
  const donutRadius = 62;
  const donutCircumference = 2 * Math.PI * donutRadius;
  let cumulativePct = 0;

  return (
    <div className="space-y-6">
      {/* Header & Date Range Filter */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
            Expenditure Analytics & Reports
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 font-mono tabular-nums">
            Analyzing {startDate} to {endDate} · {kpiStats.totalMeals} recorded meals
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div
            role="group"
            aria-label="Analytics time range"
            className="inline-flex items-center gap-1 p-1 rounded-xl bg-slate-200/70 dark:bg-slate-800/80"
          >
            {(
              [
                { id: '7d', label: 'Last 7 Days' },
                { id: '15d', label: 'Last 15 Days' },
                { id: 'cycle', label: 'Current Cycle' },
                { id: 'custom', label: 'Custom Range' },
              ] as const
            ).map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => setRangeFilter(opt.id)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  rangeFilter === opt.id
                    ? 'bg-white dark:bg-[#111C33] text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={onExportMonthlyReport}
            className="inline-flex items-center gap-1.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#111C33] hover:bg-slate-50 dark:hover:bg-slate-800 px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-emerald-500" />
            <span>Export Report</span>
          </button>
        </div>
      </div>

      {/* Custom Date Range Picker if selected */}
      {rangeFilter === 'custom' && (
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111C33] p-4 flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-2">
            <label htmlFor="analytics-custom-start" className="text-xs font-medium text-slate-600 dark:text-slate-300">
              Start Date:
            </label>
            <input
              id="analytics-custom-start"
              type="date"
              value={customStart}
              onChange={(e) => setCustomStart(e.target.value)}
              className="rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 px-3 py-1.5 text-xs font-mono text-slate-900 dark:text-white"
            />
          </div>
          <div className="flex items-center gap-2">
            <label htmlFor="analytics-custom-end" className="text-xs font-medium text-slate-600 dark:text-slate-300">
              End Date:
            </label>
            <input
              id="analytics-custom-end"
              type="date"
              value={customEnd}
              onChange={(e) => setCustomEnd(e.target.value)}
              className="rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-900 px-3 py-1.5 text-xs font-mono text-slate-900 dark:text-white"
            />
          </div>
        </div>
      )}

      {/* 6 Core Analytics Summary KPIs */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3.5 font-mono tabular-nums">
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111C33] p-4">
          <div className="text-[11px] font-sans text-slate-500 dark:text-slate-400">
            Average Daily Spend
          </div>
          <div className="text-lg font-bold text-slate-900 dark:text-white mt-1">
            {formatCredits(kpiStats.avgDailySpend, creditFormat)} cr
          </div>
          <div className="text-[10px] font-sans text-slate-500 dark:text-slate-400 mt-0.5">
            Across {kpiStats.activeDaysCount} active day{kpiStats.activeDaysCount === 1 ? '' : 's'}
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111C33] p-4">
          <div className="text-[11px] font-sans text-slate-500 dark:text-slate-400">
            Average Meal Cost
          </div>
          <div className="text-lg font-bold text-emerald-600 dark:text-emerald-400 mt-1">
            {formatCredits(kpiStats.avgMealCost, creditFormat)} cr
          </div>
          <div className="text-[10px] font-sans text-slate-500 dark:text-slate-400 mt-0.5">
            {kpiStats.totalMeals} total meals
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111C33] p-4">
          <div className="text-[11px] font-sans text-slate-500 dark:text-slate-400">
            Highest Spending Day
          </div>
          <div className="text-lg font-bold text-amber-600 dark:text-amber-400 mt-1">
            {kpiStats.highestDay
              ? `${formatCredits(kpiStats.highestDay.credits, creditFormat)} cr`
              : '—'}
          </div>
          <div className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
            {kpiStats.highestDay ? kpiStats.highestDay.date : 'No meals yet'}
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111C33] p-4">
          <div className="text-[11px] font-sans text-slate-500 dark:text-slate-400">
            Lowest Spending Day
          </div>
          <div className="text-lg font-bold text-sky-600 dark:text-sky-400 mt-1">
            {kpiStats.lowestDay
              ? `${formatCredits(kpiStats.lowestDay.credits, creditFormat)} cr`
              : '—'}
          </div>
          <div className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
            {kpiStats.lowestDay ? kpiStats.lowestDay.date : 'No meals yet'}
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111C33] p-4">
          <div className="text-[11px] font-sans text-slate-500 dark:text-slate-400">
            Total Meals Recorded
          </div>
          <div className="text-lg font-bold text-slate-900 dark:text-white mt-1">
            {kpiStats.totalMeals}
          </div>
          <div className="text-[10px] font-sans text-slate-500 dark:text-slate-400 mt-0.5">
            {formatCredits(kpiStats.totalCredits, creditFormat)} cr spent
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111C33] p-4">
          <div className="text-[11px] font-sans text-slate-500 dark:text-slate-400">
            Projected End Balance
          </div>
          <div
            className={`text-lg font-bold mt-1 ${
              metrics.projectedEndBalance < 0
                ? 'text-rose-600 dark:text-rose-400'
                : 'text-emerald-600 dark:text-emerald-400'
            }`}
          >
            {metrics.projectedEndBalance >= 0 ? '+' : ''}
            {formatCredits(metrics.projectedEndBalance, creditFormat)} cr
          </div>
          <div className="text-[10px] font-sans text-slate-500 dark:text-slate-400 mt-0.5">
            At current pace
          </div>
        </div>
      </div>

      {/* 1. Daily Credit Spending Line Chart */}
      <section
        aria-label="Daily Credit Spending Line Chart"
        className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111C33] p-5 sm:p-6"
      >
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              Daily Credit Spending Trend
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Daily total credits compared against the {formatCredits(cycle.dailyReference, creditFormat)} cr daily reference line.
            </p>
          </div>
          {hoveredDayIndex !== null && linePoints[hoveredDayIndex] && (
            <div className="text-xs font-mono tabular-nums bg-slate-100 dark:bg-slate-800 px-3 py-1.5 rounded-lg">
              <strong>{linePoints[hoveredDayIndex].date}</strong>:{' '}
              <span className="text-emerald-600 dark:text-emerald-400 font-bold">
                {formatCredits(linePoints[hoveredDayIndex].credits, creditFormat)} cr
              </span>{' '}
              ({linePoints[hoveredDayIndex].meals} meals)
            </div>
          )}
        </div>

        <div className="w-full overflow-x-auto">
          <svg
            viewBox={`0 0 ${chartW} ${chartH}`}
            className="w-full min-w-[480px] h-56 select-none"
            role="img"
            aria-label="Line chart of daily credit spending"
          >
            {/* Horizontal grid lines */}
            {[0, 0.25, 0.5, 0.75, 1].map((step) => {
              const y = padT + plotH - step * plotH;
              const val = Math.round(step * maxDailyY);
              return (
                <g key={step}>
                  <line
                    x1={padL}
                    y1={y}
                    x2={chartW - padR}
                    y2={y}
                    stroke="currentColor"
                    strokeDasharray="3 3"
                    className="text-slate-200 dark:text-slate-800"
                  />
                  <text
                    x={padL - 8}
                    y={y + 4}
                    textAnchor="end"
                    className="fill-slate-400 dark:fill-slate-500 text-[10px] font-mono"
                  >
                    {val}
                  </text>
                </g>
              );
            })}

            {/* 288 Daily Reference Line */}
            <line
              x1={padL}
              y1={refLineY}
              x2={chartW - padR}
              y2={refLineY}
              stroke="#F59E0B"
              strokeWidth="1.5"
              strokeDasharray="5 4"
            />
            <text
              x={chartW - padR - 4}
              y={refLineY - 5}
              textAnchor="end"
              className="fill-amber-500 text-[10px] font-mono font-semibold"
            >
              Ref: {cycle.dailyReference} cr
            </text>

            {/* Spending Polyline */}
            {linePoints.length > 1 && (
              <polyline
                fill="none"
                stroke="#10B981"
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                points={polylineStr}
              />
            )}

            {/* Data Points & X-axis labels */}
            {linePoints.map((pt, idx) => {
              const showLabel =
                linePoints.length <= 10 ||
                idx === 0 ||
                idx === linePoints.length - 1 ||
                idx % Math.ceil(linePoints.length / 7) === 0;
              return (
                <g
                  key={pt.date}
                  onMouseEnter={() => setHoveredDayIndex(idx)}
                  onClick={() => setHoveredDayIndex(idx)}
                  className="cursor-pointer"
                >
                  <circle
                    cx={pt.x}
                    cy={pt.y}
                    r={hoveredDayIndex === idx ? 6 : 4}
                    fill={pt.credits > cycle.dailyReference ? '#F59E0B' : '#10B981'}
                    stroke="#0B1120"
                    strokeWidth="1.5"
                  />
                  {showLabel && (
                    <text
                      x={pt.x}
                      y={chartH - 10}
                      textAnchor="middle"
                      className="fill-slate-500 dark:fill-slate-400 text-[10px] font-mono"
                    >
                      {pt.label}
                    </text>
                  )}
                </g>
              );
            })}
          </svg>
        </div>
      </section>

      {/* Middle Split: Category Pie/Donut Breakdown + Weekly Spending Bar Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Meal-Category Pie/Donut Chart & Comparison */}
        <section
          aria-label="Meal Category Spending Breakdown"
          className="lg:col-span-7 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111C33] p-5 sm:p-6"
        >
          <div className="mb-4">
            <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <PieChartIcon className="w-4 h-4 text-emerald-500" />
              <span>Meal-Category Spending Breakdown</span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Breakfast vs Lunch vs Snacks vs Dinner comparison by total credits and average cost.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-6">
            {/* SVG Donut Chart */}
            <div className="relative w-40 h-40 shrink-0 flex items-center justify-center">
              <svg className="w-40 h-40 -rotate-90" viewBox="0 0 160 160">
                <circle
                  cx="80"
                  cy="80"
                  r={donutRadius}
                  fill="transparent"
                  stroke="currentColor"
                  strokeWidth="18"
                  className="text-slate-100 dark:text-slate-800"
                />
                {categoryBreakdown.map((item) => {
                  if (item.pct <= 0) return null;
                  const strokeLength = (item.pct / 100) * donutCircumference;
                  const offset = donutCircumference - strokeLength;
                  const rotationOffset = (cumulativePct / 100) * 360;
                  cumulativePct += item.pct;
                  return (
                    <circle
                      key={item.category}
                      cx="80"
                      cy="80"
                      r={donutRadius}
                      fill="transparent"
                      stroke={item.color}
                      strokeWidth="18"
                      strokeDasharray={donutCircumference}
                      strokeDashoffset={offset}
                      transform={`rotate(${rotationOffset} 80 80)`}
                    />
                  );
                })}
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                <span className="text-base font-bold font-mono tabular-nums text-slate-900 dark:text-white">
                  {formatCredits(kpiStats.totalCredits, creditFormat)}
                </span>
                <span className="text-[10px] text-slate-500 dark:text-slate-400">
                  total cr
                </span>
              </div>
            </div>

            {/* Category Comparison Table */}
            <div className="w-full divide-y divide-slate-100 dark:divide-slate-800/80 text-xs">
              {categoryBreakdown.map((cat) => (
                <div
                  key={cat.category}
                  className="py-2.5 flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-2.5">
                    <span
                      className="w-3 h-3 rounded-xs shrink-0"
                      style={{ backgroundColor: cat.color }}
                    />
                    <div>
                      <span className="font-semibold text-slate-900 dark:text-white">
                        {cat.category}
                      </span>
                      <span className="text-slate-500 dark:text-slate-400 ml-2 font-mono tabular-nums">
                        ({cat.count} meal{cat.count === 1 ? '' : 's'} · avg {formatCredits(cat.avgCost, creditFormat)} cr)
                      </span>
                    </div>
                  </div>
                  <div className="font-mono tabular-nums text-right">
                    <span className="font-bold text-slate-900 dark:text-white">
                      {formatCredits(cat.credits, creditFormat)} cr
                    </span>
                    <span className="text-slate-500 dark:text-slate-400 ml-2">
                      ({formatCredits(cat.pct, 'integer-preferred')}%)
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Weekly Spending Bar Chart & Summaries */}
        <section
          aria-label="Weekly Spending Breakdown"
          className="lg:col-span-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111C33] p-5 sm:p-6 flex flex-col justify-between"
        >
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-emerald-500" />
              <span>Weekly Cycle Summaries</span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Weekly credit totals across the current {cycle.cycleDuration}-day billing cycle.
            </p>

            <div className="mt-4 space-y-3.5">
              {weeklySummaries.map((wk) => {
                const maxBar = Math.max(wk.reference * 1.2, wk.credits, 1);
                const barWidthPct = Math.min(100, Math.round((wk.credits / maxBar) * 100));
                const isOverRef = wk.credits > wk.reference;
                return (
                  <div key={wk.weekNum} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-slate-800 dark:text-slate-200">
                        Week {wk.weekNum}{' '}
                        <span className="font-normal font-mono text-slate-500 dark:text-slate-400">
                          ({wk.rangeLabel})
                        </span>
                      </span>
                      <span className="font-mono tabular-nums font-bold text-slate-900 dark:text-white">
                        {formatCredits(wk.credits, creditFormat)} / {formatCredits(wk.reference, creditFormat)} cr
                      </span>
                    </div>
                    <div className="w-full h-2.5 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-300 ${
                          isOverRef ? 'bg-amber-500' : 'bg-emerald-500'
                        }`}
                        style={{ width: `${barWidthPct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="mt-5 pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400 font-mono tabular-nums">
            7-day reference target: {formatCredits(cycle.dailyReference * 7, creditFormat)} credits/week ({formatCredits(cycle.dailyReference, creditFormat)} cr × 7 days)
          </div>
        </section>
      </div>

      {/* Full Smart Insights Section */}
      <section
        aria-label="Detailed Smart Insights"
        className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#111C33] p-5 sm:p-6"
      >
        <div className="mb-4">
          <h2 className="text-base font-bold text-slate-900 dark:text-white">
            Data-Driven Smart Insights
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Generated strictly from your stored meal transactions and billing cycle metrics.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {insights.map((ins) => (
            <div
              key={ins.id}
              className="rounded-xl border border-slate-200/80 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/40 p-4 flex items-start justify-between gap-3"
            >
              <div>
                <div className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                  {ins.type === 'positive' && (
                    <TrendingDown className="w-4 h-4 text-emerald-500 shrink-0" />
                  )}
                  {ins.type === 'warning' && (
                    <TrendingUp className="w-4 h-4 text-amber-500 shrink-0" />
                  )}
                  <span>{ins.title}</span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 leading-relaxed">
                  {ins.description}
                </p>
              </div>
              {ins.metric && (
                <span className="font-mono text-xs font-bold tabular-nums text-emerald-600 dark:text-emerald-400 whitespace-nowrap shrink-0">
                  {ins.metric}
                </span>
              )}
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};
