import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.vit.messmate',
  appName: 'VIT MessMate',
  webDir: 'dist',
  bundledWebRuntime: false,
  android: {
    backgroundColor: '#0B1120',
    allowMixedContent: false,
  },
};

export default config;
