# VIT MessMate Android build

VIT MessMate is a local-first mess credit tracker. The Android build bundles the web app inside a Capacitor Android shell, so it works offline and stores data on the phone using IndexedDB.

## Defaults
- Daily reference: 288 credits
- Cycle length: 30 days
- Starting cycle budget: 8,640 credits
- No daily spending cap
- Starts with **zero recorded meals** (no demo transactions)

## Build an APK with GitHub Actions
This source includes `.github/workflows/build-android-apk.yml`.

1. Extract this ZIP on a computer or phone.
2. Create a new GitHub repository.
3. Upload the **contents** of this folder to the repository root (the `.github` folder must also be uploaded).
4. Open the repository's **Actions** tab.
5. Select **Build VIT MessMate Android APK** and press **Run workflow** (or push to `main`).
6. Wait for the workflow to finish successfully.
7. Open the completed workflow run, scroll to **Artifacts**, and download `VIT-MessMate-debug-APK`.
8. Extract the downloaded artifact and install `app-debug.apk` on your Android phone. If Android asks, allow installation from that source.

The GitHub Actions runner supplies the Android SDK and builds the APK. This workspace does not contain an Android SDK, so the APK cannot be compiled locally here.

## Local development
Requires Node.js 22 and Android Studio / Android SDK.

```bash
npm install
npm run dev
```

To generate and build the Android project:

```bash
npm run build
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

APK output: `android/app/build/outputs/apk/debug/app-debug.apk`

## Data and privacy
- Meal entries and settings are stored locally on the device.
- No account or cloud sync is configured.
- Export your data regularly from Settings if you want a backup.
- Uninstalling the app or clearing its storage may delete local records.
